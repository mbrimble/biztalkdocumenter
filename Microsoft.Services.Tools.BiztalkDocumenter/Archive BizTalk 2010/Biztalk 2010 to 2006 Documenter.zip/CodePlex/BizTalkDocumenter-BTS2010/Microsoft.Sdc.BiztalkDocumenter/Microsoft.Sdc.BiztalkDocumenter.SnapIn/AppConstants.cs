
namespace Microsoft.Services.Tools.BiztalkDocumenter.SnapIn
{

    public class AppConstants
    {
        public static readonly string DocResultViewGuid = "44D98E3D-69FD-4b2e-8541-5B7A6CB2BC75";
    }
}
