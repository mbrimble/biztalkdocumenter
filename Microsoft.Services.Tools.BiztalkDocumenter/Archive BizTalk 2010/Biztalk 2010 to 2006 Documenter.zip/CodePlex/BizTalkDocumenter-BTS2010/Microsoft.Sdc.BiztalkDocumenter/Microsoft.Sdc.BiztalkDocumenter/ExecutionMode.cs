
namespace Microsoft.Services.Tools.BiztalkDocumenter
{

    /// <summary>
    /// Summary description for ExecutionMode.
    /// </summary>
    public enum ExecutionMode
    {
        CommandLine = 1,
        Interactive = 2,
    }
}
