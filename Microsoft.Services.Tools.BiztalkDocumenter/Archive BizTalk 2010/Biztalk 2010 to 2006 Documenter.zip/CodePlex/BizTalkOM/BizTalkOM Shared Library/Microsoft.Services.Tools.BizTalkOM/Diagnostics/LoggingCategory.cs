﻿
namespace Microsoft.Services.Tools.BizTalkOM.Diagnostics
{
    public enum LoggingCategory
    {
        General = 0,
        Info = 1,
        Warning = 2,
        Trace = 3,
        Error = 4
    }
}
