
namespace Microsoft.Services.Tools.BizTalkOM
{

    /// <summary>
    /// Summary description for Constants.
    /// </summary>
    public class Constants
    {
        public static string NamespacePath = @"root\MicrosoftBizTalkServer";

        public static string WmiSendPortClassName = @"MSBTS_SendPort";
    }
}
