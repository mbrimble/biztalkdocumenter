﻿
namespace Microsoft.Services.Tools.BizTalkOM
{
    internal delegate void ObjectAddedEvent(BizTalkBaseObject obj);
}
