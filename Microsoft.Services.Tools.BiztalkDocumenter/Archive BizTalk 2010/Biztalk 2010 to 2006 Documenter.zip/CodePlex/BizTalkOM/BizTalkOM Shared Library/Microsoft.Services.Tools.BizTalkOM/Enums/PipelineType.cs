
namespace Microsoft.Services.Tools.BizTalkOM
{

    public enum PipelineType
    {
        Receive = 1,
        Send = 2,
        Transform = 3,
        Unknown = 0
    }
}
