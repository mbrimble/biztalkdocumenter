
namespace Microsoft.Services.Tools.BizTalkOM
{
    using System;

    [Flags()]
    public enum LoadOption
    {
        Complete = 2,
        SchemaOnly = 4,
    }
}
