
namespace Microsoft.Services.Tools.BizTalkOM
{

    public enum SchemaType
    {
        Document = 0,
        Property = 1,
        Envelope = 2,
    }
}
