
namespace Microsoft.Services.Tools.BizTalkOM
{

    public enum BindingType
    {
        Direct = 3,
        Dynamic = 4,
        Logical = 1,
        Physical = 2,
        Role = 5
    }
}
