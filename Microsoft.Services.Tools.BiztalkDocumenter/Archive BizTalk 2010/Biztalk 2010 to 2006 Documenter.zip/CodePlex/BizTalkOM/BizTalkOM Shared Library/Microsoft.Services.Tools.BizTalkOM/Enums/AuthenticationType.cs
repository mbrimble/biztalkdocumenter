
namespace Microsoft.Services.Tools.BizTalkOM
{

    public enum AuthenticationType
    {
        NotRequired = 0,
        RequiredDropMessage = 1,
        RequiredKeepMessage = 2
    }
}
