using System.Diagnostics;

namespace Microsoft.Services.Tools.BizTalkOM.Tests
{
    using System;
    using System.Collections;
    using System.Text;
    using System.Xml;
    using System.Xml.Linq;
    using BtsCore = Microsoft.BizTalk.ExplorerOM;
    using Microsoft.Services.Tools.BizTalkOM;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Some general tests to exercise the OM. 
    /// These require the default "BizTalk Application 1" to be available for most of the tests
    /// as the installation load is filtered on that to save time. 
    /// The tests themselves are not very useful beyond exercising the system as they dont 
    /// actually Assert anything meaningull. These be completely rewritten in the next version.
    /// </summary>
    [TestClass]
    public class ArtifactTests
    {
        [TestMethod]
        public void GetOrchestrationNames()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";

            ArrayList a = bi.GetOrchestrationNames();
            System.Diagnostics.Debug.WriteLine("Number of orchestrations : " + a.Count);

            Assert.IsTrue(a.Count > 0);
        }

        /// <summary>
        /// Exercises the functionality to get schema information
        /// </summary>
        [TestMethod]
        public void GetSchemaNames()
        {
            // Get the schema info from explorer so we can compare with what we get from the installation
            string ConnectionStringFormat = "Server={0};Database={1};Integrated Security=SSPI";
            BtsCore.BtsCatalogExplorer explorer = new BtsCore.BtsCatalogExplorer();
            explorer.ConnectionString = string.Format(ConnectionStringFormat, "(local)", "BizTalkMgmtDb");
            BtsCore.Application app = explorer.Applications["BizTalk Application 1"];

            Debug.WriteLine("EXPLORER SCHEMAS : " + app.Schemas.Count);
            foreach (BtsCore.Schema schema in app.Schemas)
            {
                Debug.WriteLine(schema.FullName + " : " + schema.Type);
            }

            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk Application 1");
            bi.LoadConfig(requestedApps, false);

            Debug.WriteLine("INSTALLATION SCHEMAS :" + bi.Schemas.Count);
            foreach (Schema s in bi.Schemas)
            {
                Debug.WriteLine(s.Name + " : " + s.SchemaType);
            }

            Assert.AreEqual(app.Schemas.Count, bi.Schemas.Count);


        }

        [TestMethod]
        public void RetrievePipelines()
        {
            string ConnectionStringFormat = "Server={0};Database={1};Integrated Security=SSPI";
            BtsCore.BtsCatalogExplorer explorer = new BtsCore.BtsCatalogExplorer();
            explorer.ConnectionString = string.Format(ConnectionStringFormat, "(local)", "BizTalkMgmtDb");
            BtsCore.Application app = explorer.Applications["BizTalk.System"];

            foreach (BtsCore.Pipeline pipeline in app.Pipelines)
            {
                Debug.WriteLine(pipeline.FullName);
            }

            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk.System");
            bi.LoadConfig(requestedApps, false);

            foreach (Pipeline pipe in bi.Pipelines)
            {
                Debug.WriteLine(pipe.Name);
            }


        }


        [TestMethod]
        public void GetOrchestrationsInAssembly()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk Application 1");
            bi.LoadConfig(requestedApps, false);

            ArrayList ai = bi.GetOrchestrationNames();
            Console.WriteLine("There are " + ai.Count + " orchestrations deployed in this BizTalk Group");
            foreach (string assemblyOrchestration in ai)
            {
                string[] splitArray = assemblyOrchestration.Split('|');
                string assemblyName = splitArray[0];
                string orchestrationName = splitArray[1];
                System.Diagnostics.Debug.WriteLine(orchestrationName);
                Console.WriteLine(orchestrationName);
            }
        }

        [TestMethod]
        public void ReceiveHandlerTest()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk Application 1");
            bi.LoadConfig(requestedApps, false);

            foreach (BizTalkApplication application in bi.Applications)
            {
                foreach (ReceivePort rp in application.ReceivePorts)
                {
                    foreach (ReceiveLocation rl in rp.ReceiveLocations)
                    {
                        Assert.IsNotNull(rl.ReceiveHandler);
                    }
                }
            }
        }

        [TestMethod]
        public void RetrieveReceivePorts()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk Application 1");
            bi.LoadConfig(requestedApps, false);

            foreach (BizTalkApplication application in bi.Applications)
            {
                foreach (ReceivePort rp in application.ReceivePorts)
                {
                    Console.WriteLine("Receive Port Name: " + rp.Name);
                }
            }
        }

        [TestMethod]
        public void RetrieveSendPorts()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk Application 1");
            bi.LoadConfig(requestedApps, false);

            foreach (BizTalkApplication application in bi.Applications)
            {
                foreach (SendPort sp in application.SendPorts)
                {
                    Console.WriteLine("Send Port Name: " + sp.Name);
                }
            }
        }


        [TestMethod]
        public void GenerateDefaultApplicationInstallationXml()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk Application 1");
            bi.LoadConfig(requestedApps, false);
            this.InstallationWrite(bi, "application1");

        }

        [TestMethod]
        public void GenerateSystemApplicationInstallationXml()
        {
            BizTalkInstallation bi = new BizTalkInstallation();
            bi.MgmtDatabaseName = "BizTalkMgmtDb";
            bi.Server = "(local)";
            ArrayList requestedApps = new ArrayList();
            requestedApps.Add("BizTalk.System");
            bi.LoadConfig(requestedApps, false);
            this.InstallationWrite(bi, "system");

        }



        /// <summary>
        /// Useful utility method
        /// </summary>
        private void InstallationWrite(BizTalkInstallation bi, string fileName)
        {
            if (String.IsNullOrEmpty(fileName))
            {
                fileName = "install";
            }

            string xmlConfigDocument = bi.GetXml();
            XDocument xDocument = XDocument.Parse(xmlConfigDocument);


            using (XmlTextWriter xtw = new XmlTextWriter(@"c:\temp\" + fileName + ".xml", Encoding.UTF8))
            {
                xDocument.WriteTo(xtw);
            }

            // Bug previously through an exception on the previous line, if it get's here it's fixed
            Assert.IsNotNull(xmlConfigDocument);
        }
    }
}
