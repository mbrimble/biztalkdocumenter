﻿namespace Microsoft.Services.Tools.BizTalkOM.Tests
{
    using Microsoft.Services.Tools.BizTalkOM;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Summary description for DomainObjectTests
    /// </summary>
    [TestClass]
    public class ArtifactComparerTests
    {

        [TestMethod]
        public void ExpectArtifactComparerReturnsTrueForEqualObjects()
        {
            ArtifactKey x = new ArtifactKey("a", "b");
            ArtifactKey y = new ArtifactKey("a", "b");
            ArtifactKeyComparer comparer = new ArtifactKeyComparer();
            Assert.IsTrue(comparer.Equals(x, y));
        }

        [TestMethod]
        public void ExpectArtifactComparerReturnsFalseForNonEqualObjects()
        {
            ArtifactKey x = new ArtifactKey("a", "b");
            ArtifactKey y = new ArtifactKey("c", "d");
            ArtifactKeyComparer comparer = new ArtifactKeyComparer();
            Assert.IsFalse(comparer.Equals(x, y));
        }

    }
}
