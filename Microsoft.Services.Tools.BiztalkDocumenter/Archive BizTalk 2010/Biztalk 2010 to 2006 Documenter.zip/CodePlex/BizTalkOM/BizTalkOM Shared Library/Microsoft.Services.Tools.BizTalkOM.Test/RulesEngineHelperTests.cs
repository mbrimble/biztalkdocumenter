﻿namespace Microsoft.Services.Tools.BizTalkOM.Tests
{
    using System;
    using System.Collections;
    using Microsoft.Services.Tools.BizTalkOM;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class RulesEngineHelperTests
    {
        private RulesEngineHelper helper = new RulesEngineHelper("localhost", "BizTalkRuleEngineDb");

        /// <summary>
        /// Exercises the GetVocabularies method.
        /// This needs the SDK samples HelloWorld1 and HelloWorld2
        /// </summary>
        [TestMethod]
        public void ExpectCallToGetVocabulariesReturnsAllData()
        {
            BizTalkBaseObjectCollectionEx results = helper.GetVocabularies();
            Assert.IsTrue(results.ObjectCount > 0);
        }

        [TestMethod]
        public void ExpectCallToGetRuleSetsReturnsAllData()
        {
            BizTalkBaseObjectCollectionEx results = helper.GetRuleSets();
            Assert.IsTrue(results.ObjectCount > 0);
        }


    }
}
