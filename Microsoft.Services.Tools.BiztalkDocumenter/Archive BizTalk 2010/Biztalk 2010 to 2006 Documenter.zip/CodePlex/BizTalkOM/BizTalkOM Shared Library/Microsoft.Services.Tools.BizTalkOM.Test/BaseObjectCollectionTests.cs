﻿using System.Diagnostics;

namespace Microsoft.Services.Tools.BizTalkOM.Tests
{
    using System;
    using Microsoft.Services.Tools.BizTalkOM;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Summary description for DomainObjectTests
    /// </summary>
    [TestClass]
    public class BaseObjectCollectionTests
    {

        /// <summary>
        /// Test that we can add an object to the collection and retrieve the same one by Index.
        /// </summary>
        [TestMethod]
        public void ExpectUniqueAdditionsAreAccepted()
        {
            BizTalkBaseObjectCollectionEx coll = new BizTalkBaseObjectCollectionEx();

            // Create a BTS item and add it to the collection
            SendPort input = new SendPort();
            input.QualifiedName = "qname1";
            input.Name = "port1";
            coll.Add(input);

            // Get the item
            BizTalkBaseObject obj = coll[0];

            Assert.IsTrue(input.QualifiedName.Equals(obj.QualifiedName));
            Assert.IsTrue(input.Name.Equals(obj.Name));
        }

        /// <summary>
        /// Test that we can add an object to the collection and retrieve by ArtifactName
        /// </summary>
        [TestMethod]
        public void ExpectEntriesAreLocatedByArtifactName()
        {
            BizTalkBaseObjectCollectionEx coll = new BizTalkBaseObjectCollectionEx();

            // Create a BTS item and add it to the collection
            SendPort input = new SendPort();
            input.QualifiedName = "qname1";
            input.Name = "port1";
            coll.Add(input);

            // get the item
            BizTalkBaseObject result = coll["port1"];

            Assert.IsTrue(input.QualifiedName.Equals(result.QualifiedName));
            Assert.IsTrue(input.Name.Equals(result.Name));
        }

        /// <summary>
        /// Test that we can add artifacts with duplicate artifactNames (the QName must be different).
        /// </summary>
        [TestMethod]
        public void ExpectDuplicateArtifactNamesAreAccepted()
        {
            BizTalkBaseObjectCollectionEx coll = new BizTalkBaseObjectCollectionEx();

            // Create a BTS item and add it to the collection
            SendPort input1 = new SendPort();
            input1.QualifiedName = "qname1";
            input1.Name = "port1";
            coll.Add(input1);

            SendPort input2 = new SendPort();
            input2.QualifiedName = "version2";
            input2.Name = "port1";
            coll.Add(input2);

            Assert.IsTrue(coll.ObjectCount == 2);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ExpectExceptionIfDuplicateArtifactIsAdded()
        {
            BizTalkBaseObjectCollectionEx coll = new BizTalkBaseObjectCollectionEx();

            // Create a BTS item and add it to the collection
            SendPort input1 = new SendPort();
            input1.QualifiedName = "qname1";
            input1.Name = "port1";
            coll.Add(input1);

            // Attempt to force a duplicate entry which should throw an exception
            coll.Add(input1);
        }

        [TestMethod]
        public void ExpectSortingInAscendingOrder()
        {
            CollectionSorter comparer = new CollectionSorter(CollectionSorter.SortOrder.Ascending, "Name");
            BizTalkBaseObjectCollectionEx coll = new BizTalkBaseObjectCollectionEx();

            // Create a BTS item and add it to the collection
            SendPort inputz = new SendPort();
            inputz.Name = "z";
            inputz.QualifiedName = "QNamez";
            coll.Add(inputz);

            SendPort inputy = new SendPort();
            inputy.Name = "y";
            inputy.QualifiedName = "QNamey";
            coll.Add(inputy);

            SendPort inputb = new SendPort();
            inputb.Name = "b";
            inputb.QualifiedName = "QNameb";
            coll.Add(inputb);

            SendPort inputa = new SendPort();
            inputa.Name = "a";
            inputa.QualifiedName = "QNamea";
            coll.Add(inputa);

            // Now perform the sort
            coll.Sort(comparer);


            foreach (BizTalkBaseObject entry in coll)
            {
                Debug.WriteLine("ENTRY = " + entry.Name + " : " + entry.QualifiedName);
            }

            Assert.IsTrue(coll[0].Name.Equals("a"));
            Assert.IsTrue(coll[1].Name.Equals("b"));
            Assert.IsTrue(coll[2].Name.Equals("y"));
            Assert.IsTrue(coll[3].Name.Equals("z"));



        }
    }
}
